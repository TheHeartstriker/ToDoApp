//TypeScript type definitions for Provider.tsx
//Task data structure
export interface taskStuct {
  task_id: id;
  ToDoHeader: task;
  Description: description;
  Folder: folder;
  Completed: boolean;
}

export interface folderStruct {
  folderOn: boolean;
  index: folders;
  folder: folder;
}
