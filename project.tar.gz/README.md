
# Description
This is a todo app... aaaand that's it thank you for coming to my ted talk. Anyway yes this is a very common website but for learning purposes it was great I learned a lot about backend, system creation/development and how to safely do http requests and interact with a database. It has a fairly unique ui I think and more things then I think most would implement. Login, ids, folders, task names, task completion, and descriptions. I learned a ton during its creation and I am glad I did it.

# Todo Link 
https://www.genesistodo.com 

# Little tech overview 
How it works / what it uses The I tried to keep the app very component based. It interacts with the backend through node and express which then goes through the server. It rather secure using JWT and cors. Its hosted on an ec2 in the cloud through AWS it uses ubuntu and caddy for a reverse proxy.
